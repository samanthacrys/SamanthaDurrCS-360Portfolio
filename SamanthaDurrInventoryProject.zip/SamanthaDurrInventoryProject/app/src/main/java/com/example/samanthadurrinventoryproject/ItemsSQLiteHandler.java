/*
Samantha Durr
CS-260
Project 3, Option 1: Inventory App
 */
package com.example.samanthadurrinventoryproject;

public class ItemsSQLiteHandler {
    public void createItem(Item item) {
    }
}
